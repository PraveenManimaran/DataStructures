
/*
 * Lab #1
 * Name: Praveen Manimaran
 * This assignment demonstrates inheritance and polymorphism through the use of a Wallet class which 
 * uses methods in the Dollar and CIS22CDollar class(base class of Dollar class) to help provide 2 different 
 * kinds of currency for the user. The user can add, subtract, compare, the two currencies in the wallet by entering 
 * values.
 * 
 */



import java.util.Scanner;

public class Lab1Main 
{


	public static void main(String[] args) 
	{

		/* while loop(until user selects quit option)
		   		prompts user to add/subtract/compare/print currency in wallet
		   		operation = scanner scans next string
		   		if(checks is user typed in any operation besides print)
		   			asks user which Dollar they want
		   		else
		   			print values in wallet
		   		if(checks if user selected currency Dollar)
		   			if (user selected compare option)
		   				asks user to input value to compare and creates Dollar object
		   				calls methods to perform function 
		   			else if(user selected add option)
		   				asks user to input value to add and creates Dollar object
		   				calls methods to perform function 
		   			else if(user selected subtract option)
		   				asks user to input value to subtract and creates Dollar object 
		   				calls methods to perform function 
		   		else if(	checks if user selected currency CIS22CDollar)
		   			if (user selected compare option)
		   				asks user to input value to compare and creates CIS22CDollar object
		   				calls methods to perform function 
		   			else if(user selected add option)
		   				asks user to input value to add and creates CIS22CDollar object
		   				calls methods to perform function 
		   			else if(user selected subtract option)
		   				asks user to input value to subtract and creates CIS22CDollar object 
		   				calls methods to perform function 
		   				
		   		if(user wants to quit program)
		   			boolean variable quitting is set to true and while loop ends if yes is selected
		   			otherwise, program continues
		 */




		//Creates Wallet and local variables to be used
		Wallet wallet = new Wallet();
		Scanner scanner = new Scanner(System.in);
		boolean quit = false;
		String currency = "";
		String operation;

		//Introduces user to program
		System.out.println("Hello Welcome to Currency Simulator!");
		System.out.println("You will be asked to enter dollars(integer) and then enter cents(integer) on separate lines");
		System.out.println();

		while(!quit)
		{
			System.out.println("Type add to add, sub to subtract, compare to compare  "
					+ "the Dollar and CIS22CDollar, or print to print Wallet:  ");

			operation = scanner.next();
			if (!(operation.equals("Print") || operation.equals("print")  ))
			{

				System.out.println("Which currency do you want to select? Type Dollar or CIS22C:  ");
				currency = scanner.next();
			}
			else
			{
				wallet.printValues(wallet);
			}


			if(currency.equals("Dollar") || currency.equals("dollar"))
			{
				if(operation.equals("compare") || operation.equals("Compare"))
				{
					System.out.println("Enter number of dollars you would like to compare your wallet with: ");
					int numDollars;
					numDollars = scanner.nextInt();
					System.out.println("Enter number of cents you would like to compare your wallet with: ");
					int numCents;
					numCents = scanner.nextInt();
					Dollar d1 = new Dollar(numDollars, numCents, "Dollar");

					if(wallet.compareDollars(wallet, d1) == true)
						System.out.println("Amount in Wallet is bigger");
					else if(wallet.compareDollars(wallet, d1) == false)
					{
						System.out.println("Amount in Wallet is smaller than inputted value of " + numDollars + " dollars and " + numCents + " cents");
					}

				}
				else if(operation.equals("add") || operation.equals("Add"))
				{

					System.out.println("How many dollars do you want to add to your wallet? ");
					int addDollars;
					addDollars = scanner.nextInt();
					System.out.println("How many cents do you want to add to your wallet? ");
					int addCents;
					addCents = scanner.nextInt();

					Dollar d1 = new Dollar(addDollars, addCents, "Dollar");

					wallet.addDollars(wallet,d1);
				}
				else if (operation.equals("sub") || operation.equals("Sub"))
				{
					System.out.println("How many dollars do you want to subtract from your wallet? ");
					int subDollars;
					subDollars = scanner.nextInt();

					System.out.println("How many cents do you want to subtract from your wallet? ");
					int subCents;
					subCents = scanner.nextInt();

					Dollar d1 = new Dollar(subDollars, subCents, "Dollar");
					wallet.subDollars(wallet,d1);
				}


			}
			else if(currency.equals("CIS22C") || currency.equals("cis22c"))
			{
				if(operation.equals("compare") || operation.equals("Compare"))
				{
					System.out.println("Enter number of CIS22C dollars you would like to compare your wallet with: ");
					int numCIS22CDollars;
					numCIS22CDollars = scanner.nextInt();
					System.out.println("Enter number of CIS22C cents you would like to compare your wallet with: ");
					int numCIS22CCents;
					numCIS22CCents = scanner.nextInt();
					CIS22CDollar c2d = new CIS22CDollar(numCIS22CDollars, numCIS22CCents, "CIS22CDollar");

					if(wallet.compareCIS22CDollars(wallet, c2d) == true)
						System.out.println("Amount in Wallet is bigger");
					else if(wallet.compareCIS22CDollars(wallet, c2d) == false)
					{
						System.out.println("Amount in Wallet is smaller than inputted value of " + numCIS22CDollars + " dollars and " + numCIS22CCents + " cents");
					}

				}
				else if(operation.equals("add") || operation.equals("Add"))
				{

					System.out.println("How many CIS22C dollars do you want to add to your wallet? ");
					int addCIS22CDollars;
					addCIS22CDollars = scanner.nextInt();

					System.out.println("How many CIS22C cents do you want to add to your wallet? ");
					int addCIS22CCents;
					addCIS22CCents = scanner.nextInt();

					CIS22CDollar c2d = new CIS22CDollar(addCIS22CDollars, addCIS22CCents, "CIS22CDollar");

					wallet.addCIS22CDollars(wallet,c2d);
				}
				else if (operation.equals("sub") || operation.equals("Sub"))
				{
					System.out.println("How many CIS22C Dollars do you want to subtract from your wallet? ");
					int subCIS22CDollars;
					subCIS22CDollars = scanner.nextInt();

					System.out.println("How many CIS22C cents do you want to subtract from your wallet? ");
					int subCIS22CCents;
					subCIS22CCents = scanner.nextInt();

					CIS22CDollar d1 = new CIS22CDollar(subCIS22CDollars, subCIS22CCents, "Dollar");
					wallet.subCIS22CDollars(wallet,d1);
				}
			}

			String quitting;
			System.out.println("Would you like to quit? Y or N");
			quitting = scanner.next();
			if(quitting.equals("Y") || quitting.equals("y"))
			{
				quit = true;
				System.out.println("Program has ended.");
			}
			else
				quit = false;
		}

	}

}
