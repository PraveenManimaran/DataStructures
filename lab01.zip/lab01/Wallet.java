
/*
 * Lab #1
 * Name: Praveen Manimaran
 * This class creates an array of Dollar references which has 1 Dollar object
 * and 1 CIS22CDollar object. It has add/subtract/compare/print for both of 
 * the currencies.
 * 
 */

public class Wallet 
{

	public Dollar[] myObject = new Dollar[2]; //array of Dollar references of size 2

	//Default Constructor
	public Wallet()
	{
		myObject[0] = new Dollar();
		myObject[1] = new CIS22CDollar();

	}

	/*
	 *	Adds Dollars from the wallet and the dollar object using Dollar class'
	 *	add method
	 *	Pre: w  Wallet object
	 *		 d1  The dollar object to be added
	 *	Post: numDollars has a new value
	 *		  numFraction has a new value
	 *		  totalCents has a new value
	 *	Return: wallet object
	 */
	public Wallet addDollars(Wallet w, Dollar d1)
	{
		//local variables
		int numDollars;
		int numFraction;
		double totalCents;

		//calls Dollar object's addDollars method to add values
		totalCents = w.myObject[0].addDollars(w.myObject[0], d1);
		numDollars = (int)(totalCents/100);
		numFraction = (int)(totalCents%100);

		w.myObject[0].setWhole(numDollars);
		w.myObject[0].setFraction(numFraction);

		return w;
	}

	/*
	 *	Subtracts dollars(dollar object) from the wallet using Dollar class'
	 *	subtract method
	 *	Pre: w  Wallet object
	 *		 d1  The dollar object to be subtracted
	 *	Post: numDollars has a new value
	 *		  numFraction has a new value
	 *		  totalCents has a new value
	 *	Return: wallet object
	 */
	public Wallet subDollars(Wallet w, Dollar d1)
	{
		int numDollars;
		int numFraction;
		double totalCents;

		//calls Dollar object's subDollars method to subtract from Wallet
		totalCents = w.myObject[0].subDollars(w.myObject[0], d1);
		numDollars = (int) (totalCents/100);
		numFraction = (int)(totalCents%100);

		//sets values
		w.myObject[0].setWhole(numDollars);
		w.myObject[0].setFraction(numFraction);

		return w;
	}

	/*
	 *	Adds CIS22CDollars from the wallet and the CIS22CDollar object using CIS22CDollar
	 *	class add method
	 *	Pre: w  Wallet object
	 *		 d2  The CIS22CDollar object to be added
	 *	Post: numDollars has a new value
	 *		  numFraction has a new value
	 *		  totalCents has a new value
	 *	Return: wallet object
	 */
	public Wallet addCIS22CDollars(Wallet w, CIS22CDollar d2)
	{

		int numDollars;
		int numFraction;
		double totalCents;

		//calls CIS22CDollar object's addCIS22CDollars method to add values
		totalCents = ((CIS22CDollar) w.myObject[1]).addCIS22CDollars((CIS22CDollar)(w.myObject[1]), d2);
		numDollars = (int)(totalCents/100);
		numFraction = (int)(totalCents%100);

		//sets values
		((CIS22CDollar) w.myObject[1]).setWhole(numDollars);
		((CIS22CDollar) w.myObject[1]).setFraction(numFraction);

		return w;
	}
	
	/*
	 *	Subtracts CIS22CDollars(dollar object) from the wallet using CIS22CDollar class subtract
	 *	method
	 *	Pre: w  Wallet object
	 *		 d2  The CIS22CDollar object to be subtracted 
	 *	Post: numDollars has a new value
	 *		  numFraction has a new value
	 *		  totalCents has a new value
	 *	Return: wallet object
	 */
	public Wallet subCIS22CDollars(Wallet w, CIS22CDollar d2)
	{
		int numDollars;
		int numFraction;
		double totalCents;

		//calls CIS22CDollar object's subCIS22CDollars method to subtract from Wallet
		totalCents = ((CIS22CDollar) w.myObject[1]).subCIS22CDollars((CIS22CDollar)(w.myObject[1]), d2);
		numDollars = (int)(totalCents/100);
		numFraction = (int)(totalCents%100);

		//sets values
		w.myObject[1].setWhole(numDollars);
		w.myObject[1].setFraction(numFraction);

		return w;
	}

	/*
	 *	Comparing two Dollar objects  to identify which
	 *	object(in wallet or input) is larger or smaller by calling Dollar class'
	 *	compare method
	 *	Pre: w  Wallet object
	 *		 obj1  The second dollar object to be compared 
	 *	Post: bigger  value changes
	 *	Return: true if wallet is bigger, false if obj1 is bigger
	 */
	public boolean compareDollars(Wallet w, Dollar obj1)
	{
		boolean bigger;
		//compares if wallet's dollar amount is bigger than user's input value
		bigger = w.myObject[0].compare(w.myObject[0], obj1);

		//return true if wallet value is bigger, false if input value is greater
		return bigger; 		
	}
	
	/*
	 *	Comparing two CIS22CDollar objects to identify which
	 *	object(in wallet or input) is larger or smaller by calling CIS22CDollar class'
	 *	compare method
	 *	Pre: w  Wallet object
	 *		 c2d  The second CIS22CDollar object to be compared 
	 *	Post: bigger  value changes
	 *	Return: true if wallet is bigger, false if c2d is bigger
	 */
	public boolean compareCIS22CDollars(Wallet w, CIS22CDollar c2d)
	{
		boolean bigger;
		//compares if wallet's CIS22CDollar amount is bigger than user's input value
		bigger = ((CIS22CDollar) w.myObject[1]).compare((CIS22CDollar) w.myObject[1] , c2d );

		//return true if wallet value is bigger, false if input value is greater
		return bigger; 		
	}

	/*
	 *	Print method to print the amount of Dollars and CIS22CDollars in wallet
	 *	Pre: w  The dollar object to be printed
	 *	Post: none
	 *	Return: none
	 */
	public void printValues(Wallet w)
	{
		w.myObject[0].print(w.myObject[0]);
		((CIS22CDollar) w.myObject[1]).print((CIS22CDollar) w.myObject[1]);	

	}

}
