/*
 * Lab #4
 * Name: Praveen Manimaran
 * This class contains the Main class which is the driver program that 
 * will demonstrate all the capabilities of the ADTs(stacks, LinkedList, Queues).
 * It will create 7 Node objects of Dollars to be used in the program and will
 * have stack, queue, linkedList methods being applied on them. 
 * 
 */

public class Main {

	public static void main(String[] args) 
	{
		LinkedList list1 = new LinkedList(); //creates LinkedList object
		Stack stack1 = new Stack(); //creates Stack object
		Queue queue1 = new Queue(); //creates Queue Object

		//calls methods to demonstrate capabilities of the ADTs(stacks, LinkedList, Queues).
		printLinkedListOutput(list1);
		printStackOutput(stack1);
		printQueueOutput(queue1);


	}


	/*
	 *	Creates 7 new Node objects of Dollars and adds it to the LinkedList.
	 *	It then uses a for-loop to perform the inserted/deleted/searched functions 
	 *	in a random order. It will print out the LinkedList each time to show the 
	 *	changes in the list.
	 *	Pre:list1 the LinkedList 
	 *	Post: dollar[] has a new value
	 *		  randNum has a new value
	 *		  d8 has a new value
	 *		  num has a new value
	 *		  deleteCount has a new value
	 *		  list1 has a new value
	 *	Return: none
	 */
	
	
	public static void printLinkedListOutput(LinkedList list1)
	{
		//creates dollar array of size 7 and sets values
		Dollar[] dollar  = new Dollar[7];
		Dollar d1 = new Dollar(10, 50, "Dollar");
		Dollar d2 = new Dollar(50, 80, "Dollar");
		Dollar d3 = new Dollar(2, 90, "Dollar");
		Dollar d4 = new Dollar(3, 65, "Dollar");
		Dollar d5 = new Dollar(22, 13, "Dollar");
		Dollar d6 = new Dollar(79, 38, "Dollar");
		Dollar d7 = new Dollar(20, 76, "Dollar");


		dollar[0] = d1;
		dollar[1] = d2;
		dollar[2] = d3;
		dollar[3] = d4;
		dollar[4] = d5;
		dollar[5] = d6;
		dollar[6] = d7;
		
		//inserts 7 Nodes into LinkedList using Add Methods
		System.out.println("Inserting 7 Nodes into LinkedList using Add Methods ");
		for(int i =0; i< dollar.length; i++)
		{
			if(i==0) //if first element in array 
			{
				list1.addFirst(dollar[0]); 
			}
			else
				list1.addLast(dollar[i]); //adds to the end of the list
		}
		list1.printList();
		
		System.out.println("\n\n");
		System.out.println("Now the seven Dollar Node objects will be inserted/deleted/searched in a random order");
		int deleteCount = 0; //counter variable used to help delete the first object in list
		
		
		for(int i = 0; i<=10; i++)
		{
			int randNum = (int)(3.0*Math.random()); //creates random number from 1 to 3
			if(randNum == 0) //if inserted is chosen
			{
				System.out.println("\nA Dollar Node object will now be INSERTED into the LinkedList ");
				//creates two random numbers for dollar and cents for a new Dollar object
				int num = (int)(80.0*Math.random());
				int num2 = (int)(90.0*Math.random());
				
				Dollar d8 = new Dollar(num, num2, "Dollar");
				list1.addLast(d8); //adds to the end of LinkedList
				list1.printList(); //prints new list 
			}
			else if(randNum ==1) //if deleted is chosen
			{
				System.out.println("\nThe FIRST Dollar Node object will now be DELETED from the LinkedList ");
				list1.remove(dollar[deleteCount]); //removes the first dollar node object
				list1.printList(); //prints new list
				deleteCount++; //increments counter variable 

			}
			else //if searched function is chosen
			{
				System.out.println("\nThe following Dollar Node object will now be SEARCHED in the LinkedList: ");

				int num = (int)(7*Math.random()); // creates a random number from 0 to 6
				dollar[num].print(dollar[num]); //prints out node to find
				System.out.println();
				if((list1.find(dollar[num]) == true)) //if node is found
				{
					System.out.println("FOUND NODE OBJECT!\n");
				}
				else //if node is not found
				{
					System.out.println("CANNOT FIND OBJECT!\n");
				}
			}
		}



	}
	
	/*
	 *	Creates 7 new Node objects of Dollars and adds it to the stack.
	 *	It then uses a for-loop to perform the push/pop/peek functions 
	 *	in a random order. It will print out the before and after changes
	 *	when doing the chosen function.
	 *	Pre:stack1 the Stack
	 *	Post: dollar[] has a new value
	 *		  randNum has a new value
	 *		  num2 has a new value
	 *		  num has a new value
	 *		  list2 has a new value
	 *	Return: none
	 */


	public static void printStackOutput(Stack stack1)
	{
		
		//creates dollar array of size 7 and sets values
		Dollar[] dollar  = new Dollar[7];

		Dollar d1 = new Dollar(15, 55, "Dollar");
		Dollar d2 = new Dollar(55, 85, "Dollar");
		Dollar d3 = new Dollar(20, 93, "Dollar");
		Dollar d4 = new Dollar(32, 18, "Dollar");
		Dollar d5 = new Dollar(21, 19, "Dollar");
		Dollar d6 = new Dollar(63, 31, "Dollar");
		Dollar d7 = new Dollar(40, 16, "Dollar");


		dollar[0] = d1;
		dollar[1] = d2;
		dollar[2] = d3;
		dollar[3] = d4;
		dollar[4] = d5;
		dollar[5] = d6;
		dollar[6] = d7;

		//creates new List
		LinkedList list2 = new LinkedList();
		System.out.println("\n\n\n\n");

		//adds 7 dollar node objects to list
		System.out.println("The NEW 7 Dollar Node Objects elements for the STACK");
		for(int i =0; i< dollar.length; i++)
		{
			if(i==0)
			{
				list2.addFirst(dollar[0]);
			}
			else
				list2.addLast(dollar[i]);
		}
		list2.printList();

		//adds 7 dollar node objects to the stack 
		for(int i =0; i< dollar.length; i++)
		{

			stack1.push(dollar[i]);

		}

		System.out.println("Now the seven Dollar Node objects will be pushed/popped/peeked in a random order:");
		for(int i = 0; i<=10; i++)
		{
			int randNum = (int)(3.0*Math.random()); //creates a random number from 0 to 2
			if(randNum == 0) //if push function is chosen
			{
				System.out.println("\nTop Of stack Before PUSH: ");
				stack1.peek().print(stack1.peek()); //prints the before push 

				System.out.println("\nA Dollar Node object will now be PUSHED into the Stack ");
				
				//creates two random numbers for dollar and cents for a new Dollar object
				int num = (int)(80.0*Math.random());
				int num2 = (int)(90.0*Math.random());
				Dollar d8 = new Dollar(num, num2, "Dollar");

				stack1.push(d8); //adds to stack 
				System.out.println("\nTop Of stack After PUSH: ");
				stack1.peek().print(stack1.peek()); //prints out change in the top of stack

			}
			else if(randNum ==1) //if pop function is chosen
			{

				System.out.println("\nTop Of stack Before POP: ");
				stack1.peek().print(stack1.peek()); //prints before pop

				System.out.println("\nA Dollar Node object will now be POPPED from the Stack ");
				stack1.pop(); //removes value from top of stack 
				
				System.out.println("\nTop Of stack After POP: ");
				stack1.peek().print(stack1.peek()); //prints top of stack after pop


			}
			else //if peek function is chosen
			{
				System.out.println("\nPEEKING into the Stack: ");
				System.out.println("\nTop Of stack: ");
				stack1.peek().print(stack1.peek()); //prints out value on top of stack
			}
		}
	}

	
	/*
	 *	Creates 7 new Node objects of Dollars and adds it to the queue.
	 *	It then uses a for-loop to perform the enqueue/dequeue/peek functions 
	 *	in a random order. It will print out the before and after changes
	 *	when doing the chosen function.
	 *	Pre:queue1 the Queue
	 *	Post: dollar[] has a new value
	 *		  randNum has a new value
	 *		  num2 has a new value
	 *		  num has a new value
	 *		  d8 has a new value
	 *		  list3 has a new value
	 *	Return: none
	 */
	public static void printQueueOutput(Queue queue1)
	{
		//creates dollar array of size 7 and sets new values
		Dollar[] dollar  = new Dollar[7];

		Dollar d1 = new Dollar(6, 25, "Dollar");
		Dollar d2 = new Dollar(5, 25, "Dollar");
		Dollar d3 = new Dollar(90, 23, "Dollar");
		Dollar d4 = new Dollar(4, 16, "Dollar");
		Dollar d5 = new Dollar(18, 20, "Dollar");
		Dollar d6 = new Dollar(55, 12, "Dollar");
		Dollar d7 = new Dollar(69, 70, "Dollar");


		dollar[0] = d1;
		dollar[1] = d2;
		dollar[2] = d3;
		dollar[3] = d4;
		dollar[4] = d5;
		dollar[5] = d6;
		dollar[6] = d7;

		//creates new LinkedList
		LinkedList list3 = new LinkedList();
		System.out.println("\n\n\n\n");

		//adds 7 dollar node objects to list
		System.out.println("The NEW 7 Dollar Node Objects elements for the QUEUE");
		for(int i =0; i< dollar.length; i++)
		{
			if(i==0)
			{
				list3.addFirst(dollar[0]);
			}
			else
				list3.addLast(dollar[i]);
		}
		list3.printList(); //prints out list 

		//adds 7 dollar node objects to the queue
		for(int i =0; i< dollar.length; i++)
		{
			queue1.enqueue(dollar[i]);

		}
		
		System.out.println("Now the seven Dollar Node objects will be enqueued/dequeued/peeked in a random order:");
		for(int i = 0; i<=10; i++)
		{
			int randNum = (int)(3.0*Math.random()); //generates random # from 0 to 2
			if(randNum == 0)//if enqueue is chosen 
			{
				System.out.println("\nLast Item Of Queue Before ENQUEUE: ");
				queue1.peekRear().print(queue1.peekRear()); //prints out last item in queue

				System.out.println("\nA Dollar Node object will now be ENQUEUED onto QUEUE ");
				int num = (int)(80.0*Math.random());
				int num2 = (int)(90.0*Math.random());
				Dollar d8 = new Dollar(num, num2, "Dollar");

				queue1.enqueue(d8);//adds dollar object to queue
				System.out.println("\nLast Item  Of Queue After ENQUEUED: ");
				queue1.peekRear().print(queue1.peekRear()); //prints out new last item in queue

			}
			else if(randNum ==1) //if dequeue is chosen
			{

				System.out.println("\nFirst Item Of Queue Before DEQUEUED: ");
				queue1.peekFront().print(queue1.peekFront()); //prints out first item in queue

				System.out.println("\nA Dollar Node object will now be DEQUEUED from the QUEUE ");
				queue1.dequeue();//removes first item in queue 
				
				System.out.println("\nFirst Item Of Queue After DEQUEUED: ");
				queue1.peekFront().print(queue1.peekFront()); //prints out new first item in queue


			}
			else //if peek is chosen 
			{
				System.out.println("\nPEEKING into the front of Queue: ");
				queue1.peekRear().print(queue1.peekFront()); //prints value in front of queue
				
				System.out.println("\nPEEKING into the back of Queue: ");
				queue1.peekRear().print(queue1.peekRear());	//print value in back of queue 			
			}
		}
	}
}
















