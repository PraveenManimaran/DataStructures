/*
 * Lab #4
 * Name: Praveen Manimaran
 * This class contains the LinkedList class and includes the Node class. 
 * It has getters/setters/constructors/destructors for the attributes of the class.
 * It can (a) create new list, (b) add data, (c) delete data, (d) find data, 
 * (e) count of data items in the list, (f) is list empty, 
 * (g) empty/destroy the list and (h) print all data items in a list
 * 
 */

//import statements
import java.util.*; 

public class LinkedList
{

	//attributes
	private int count;
	private Node<Dollar> start;
	private Node<Dollar> end;
	

	//Constructs an Empty List
	public LinkedList()
	{
		start = null;
	}
	
	//Copy Constructor
	public LinkedList(LinkedList list)
	{
		this();
		Node<Dollar> ptr = list.start;
		while(ptr!=null)
		{
			addLast(ptr.data);
			ptr = ptr.next;
		}
	}

	//Node Class
	public static class Node<Dollar>
	{
		//Node attributes
		private Dollar data;
		private Node<Dollar> next;

		//Node constructor
		public Node(Dollar data, Node<Dollar> next)
		{
			this.data = data;
			this.next = next;
		}
		
		//getter methods
		public Dollar getValue()
		{
			return data;
		}
		
		// returns reference to next value in list
		public Node<Dollar> getNext()
		{
			return next;
		}
		
		//setter methods
		
		//sets the new Object value to store in this node
		public void setValue(Dollar theNewValue) 
		{
			data = theNewValue;
		}
		
		//sets reference to new next value
		public void setNext(Node<Dollar> theNewNext) 
		{
			next = theNewNext;
		}

	}
	

	//Add methods

	
	/*
	 *	Adds Dollar object to the head of the list
	 *	Pre:d1 the Dollar object to be added to list
	 *	Post: start has a new value
	 *	Return: none
	 */
	public void addFirst(Dollar d1) 
	{
		
		start = new Node<Dollar>(d1, start);
		
	}

	
	/*
	 *	Adds Dollar object to the end of the list
	 *	Pre:d1 the Dollar object to be added to list
	 *	Post: start has a new value
	 *		  end has a new value
	 *		  temp has a new value
	 *	Return: none
	 */
	public void addLast(Dollar d1)
	{
		if(start == null) //if it is the first element in list
		{
			addFirst(d1);
		}
		else
		{
			Node<Dollar> temp = start;
			while(temp.next != null) //until it reaches end
				temp = temp.next;
			Node<Dollar> node2 = new Node<Dollar>(d1, null);
			temp.next = node2;
			end = node2; //sets end value
		}
	}

	//Remove method

	/*
	 *	Removes Dollar object from the list
	 *	Pre:d1 the Dollar object to be removed to list
	 *	Post: start has a new value
	 *		  current has a new value
	 *		  previous has a new value
	 *	Return: none
	 */
	public void remove(Dollar d1)
	{
		//if list is empty
		if(isEmpty()) 
		{
			throw new RuntimeException("Cannot delete Node");
		}

		//if its the first element to be removed
		if(start.data.equals(d1) )
		{
			start = start.next;
			return;
		}

		Node<Dollar> current  = start;
		Node<Dollar> previous = null;

		//until it finds the node to be removed
		while(current != null && !current.data.equals(d1) )
		{
			previous = current;
			current = current.next;
		}
		//if it cannot find the node
		if(current == null) 
		{
			throw new RuntimeException("Cannot delete node");
		}

		//delete the current node
		previous.next = current.next;
	}
	
	
	//Find data method

	/*
	 *	Searches for the dollar object in the list and returns if it finds it
	 *	Pre:obj the Dollar object to be found
	 *	Post: first has a new value
	 *	Return: if it is found in the list
	 */
	public boolean find(Dollar obj1)
	{
		Node<Dollar> first = start;
		while(first.next!=null)
		{
			if(first.data.isEqual(first.data, obj1))
			{
				return true;
			}
			first = first.next;
		}
		return false;
	}
	
	//Count method
	
	/*
	 *	Counts the number of Dollar objects in the list
	 *	Pre:count 0
	 *	Post: count has a new value
	 *		  first has a new value
	 *	Return: the number of Dollar objects in the list
	 */
	public int count()
	{
		Node<Dollar> first = start;
		while(first.next!=null)
		{
			count++;
			first = first.next;
			
		}
		return count;
	}

	
	/*
	 *	Checks if LinkedList is empty
	 *	Pre: none
	 *	Post: none
	 *	Return: if LinkedList is empty
	 */
	public boolean isEmpty()
	{
		return start == null;
	}

	/*
	 *	Empties list
	 *	Pre: none
	 *	Post: none
	 *	Return: none
	 */
	public void destroyList()
	{
		start = null;
	}
	
	//Print All Items in list
	/*
	 *	Print All Items in list
	 *	Pre: none
	 *	Post: currNonde has a new value	  
	 *	Return: none
	 */
	public void printList()
	{

		Node<Dollar> currNode = start; 

		System.out.println("LinkedList: "); 

		// Traverse through the LinkedList 
		while (currNode != null) 
		{ 
			// Print the data at current node 
			System.out.println(currNode.data + " "); 
			currNode.data.print(currNode.data);
			System.out.println();
			// Go to next node 
			currNode = currNode.next; 
			
		} 

	}

	


}

