
/*
 * Lab #4
 * Name: Praveen Manimaran
 * This class contains the Queue class which extends the LinkedList class
 * and implements QueueInterface. It's methods include (a) create queue, 
 * (b) enqueue, (c) dequeue, (d) peekFront, (e) peekRear, 
 * and (f) destroy/empty the queue
 * 
 */

import java.util.NoSuchElementException;

public class Queue extends LinkedList implements QueueInterface<Dollar>
{
	private Node<Dollar> first;    // beginning of queue
	private Node<Dollar> last;     // end of queue

	//default Constructor 
	public Queue()
	{
		first = null;
		last = null;
	}

	/*
	 *	Adds Dollar object to the end of the queue
	 *	Pre:d1 the Dollar object to be added to queue
	 *	Post: old has a new value
	 *		  first has a new value
	 *	Return: none
	 */
	public void enqueue(Dollar obj)
	{
		
		Node<Dollar> old = last;
		last = new Node<Dollar>(obj, old);
		last.setValue(obj);
		last.setNext(null);

		if(isEmpty())
			first = last;
		else
			old.setNext(last);
	}
	
	/*
	 *	Removes Dollar object from the front of the queue
	 *	Pre: none
	 *	Post: obj1 has a new value
	 *		  first has a new value
	 *	Return: Dollar object from the front of the queue
	 */
	public Dollar dequeue()
	{
		if (isEmpty()) 
		{
			throw new NoSuchElementException("Queue underflow");
		}
		Dollar obj1 = first.getValue();
		first = first.getNext();
		if(isEmpty())
			last = null;
		return obj1;
	}
	
	/*
	 *	Returns what is in front of the queue
	 *	Pre: none
	 *	Post: none
	 *	Return: what is in front of the queue
	 */
	public Dollar peekFront()
	{
		if(isEmpty())
		{
			throw new NoSuchElementException("Queue underflow");
		}
		return first.getValue();
				
		
	}
	/*
	 *	Returns what is in the back of the queue
	 *	Pre: none
	 *	Post: none
	 *	Return: what is in the back of the queue
	 */
	public Dollar peekRear()
	{
		if(isEmpty())
		{
			throw new NoSuchElementException("Queue underflow");
		}
		return last.getValue();
	}

	/*
	 *	Empties queue
	 *	Pre: none
	 *	Post: none
	 *	Return: none
	 */
	public void destroyQueue()
	{
		while(!isEmpty())
		{
			dequeue();
		}
	}
	
	/*
	 *	Checks if queue is empty and returns true or false
	 *	Pre: none
	 *	Post: none
	 *	Return: if queue is empty or not
	 */
	public boolean isEmpty() 
	{
		return first == null;
	}


}
