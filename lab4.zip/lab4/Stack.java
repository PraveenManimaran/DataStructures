/*
 * Lab #4
 * Name: Praveen Manimaran
 * This class contains the Stack class which extends the LinkedList class
 * and implements StackInterface. It's methods include (a) create stack, 
 * (b) push, (c) pop, (d) peek, and (e) destroy/empty the stack.
 * 
 */

import java.util.*;


public class Stack extends LinkedList implements StackInterface<Dollar>
{
	
	private Node<Dollar> first;     // top of stack

	//Default constructor
	public Stack()
	{
		first = null;
	}


	/*
	 *	Pushes Dollar object to the top of the stack
	 *	Pre:d1 the Dollar object to be added to stack
	 *	Post: old has a new value
	 *	Return: none
	 */
	public void push(Dollar obj) 
	{
		
		Node<Dollar> old = first;
		first = new Node<Dollar>(obj, old);
		first.setValue(obj);
		first.setNext(old);
		

	}

	/*
	 *	Removes Dollar object from the top of the list
	 *	Pre: none
	 *	Post: d1 has a new value
	 *		  first has a new value
	 *	Return: Dollar object from the top of the list
	 */

	public Dollar pop() 
	{
		if (isEmpty())
		{
			throw new NoSuchElementException("Stack Underflow");
		}
		Dollar d1;
		d1 = first.getValue();        // save Dollar object to return
		first = first.getNext();            // deleting the first node

		return d1; 
	}

	/*
	 *	Returns what is on top of the list
	 *	Pre: none
	 *	Post: none
	 *	Return: what is on top of the list
	 */

	public Dollar peek()
	{
		if (isEmpty()) 
		{
			throw new NoSuchElementException("Stack underflow");
		}
		return first.getValue();
	}


	/*
	 *	Empties stack 
	 *	Pre: none
	 *	Post: none
	 *	Return: none
	 *
	 */

	public void destroyStack() 
	{
		while(!isEmpty())
		{
			pop();
		}

	}
	
	/*
	 *	Checks if stack is empty and returns true or false 
	 *	Pre: none
	 *	Post: none
	 *	Return: if stack is empty or not
	 *
	 */
	public boolean isEmpty() {
        return first == null;
    }






}