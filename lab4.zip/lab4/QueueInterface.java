/*
 * Lab #4
 * Name: Praveen Manimaran
 * This file is an interface for the Queue class and contains the methods 
 * the class will need to ensure that the Queue objects do not allow Linked List 
 * functions to be used on them.
 * 
 */
public interface QueueInterface<Dollar>
{	
	void enqueue(Dollar obj);	
	Dollar dequeue();	
	Dollar peekFront();
	Dollar peekRear();
	void destroyQueue();
	boolean isEmpty();

}
