/*
 * Lab #4
 * Name: Praveen Manimaran
 * This file is an interface for the Stack class and contains the methods 
 * the class will need to ensure that the Stack objects do not allow Linked List 
 * functions to be used on them.
 * 
 */

public interface StackInterface<Dollar>  
{
	Dollar peek();
	void push(Dollar obj);
	Dollar pop();
	void destroyStack();
	boolean isEmpty();
	
}