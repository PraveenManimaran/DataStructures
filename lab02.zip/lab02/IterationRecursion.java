/*
 * Lab #2
 * Name: Praveen Manimaran
 * This assignment demonstrates the use of iteration(nested loops) and recursion using helper methods
 * to check if all of the elements in the array are prime numbers. It involves user to input values
 * into the array and the user can set the size of the array. 
 * 
 */



import java.util.Scanner;

public class IterationRecursion 
{
	public static final int SORT_MAX_SIZE = 16; //max size of the array

	public static void main(String[] args) 
	{
		int numElements;
		int[] arr1; //array
		int value;
		boolean badInput = false;
		Scanner scanner = new Scanner(System.in);

		//Ask the user how many elements they want in the array; will keep
		//repeating question until size of array is <= 16
		do
		{
			badInput = false;
			System.out.println("How many elements do you want? Do not exceed " + SORT_MAX_SIZE + "!");
			numElements = scanner.nextInt();
			
			if(numElements>16)
				badInput = true;
			
		} while(badInput);
		
		
		//sets size of array 
		arr1 = new int [numElements];

		//Asks user to input values in array, until the values is between 1 and 99 
		for(int i=0; i<numElements; i++)
		{
			do
			{
				badInput = false;
				System.out.println("Enter value to input in array(Between 1 and 99): ");
				value = scanner.nextInt();
				
				if(value<=0 || value>99)
					badInput = true;
				else
					arr1[i] = value;
				
			} while (badInput);	
		}

		
		System.out.print("\n\n\n");

		//Iteration Version to check if numbers in array are prime
		System.out.println("Performing Iterative function to check if there are prime numbers\n");
		boolean primeIter;
		primeIter = isArrayPrimeIter(arr1, arr1.length);
		if(primeIter == true)
			System.out.println("Prime Array using iteration");
		else
			System.out.println("Not a Prime Array using iteration");
		 

		System.out.print("\n\n\n");

		//Recursion version to check if numbers in array are prime
		System.out.println("Performing Recursive function to check if there are prime numbers\n");
		
		boolean primeRecur;
		primeRecur = isArrayPrimeRecur(arr1, arr1.length);
		if(primeRecur == true)
			System.out.println("Prime Array using recursion");
		else
			System.out.println("Not a Prime Array using recursion");
		 
		
	}

	/*
	 *	Find out if the values in the array are prime numbers using nested 
	 *	for loops(Iteration). Will return a boolean value if numbers 
	 *	in array are prime or not
	 *	Pre: arr1  Array of user-entered numbers
	 *	Post: notPrime has a new boolean value
	 *	Return: whether or not the array consists of all prime numbers
	 */
	public static boolean isArrayPrimeIter(int[] arr1, int size)
	{
		System.out.println("Entering isArrayPrimeIter()");

		//boolean variable to check if the number is prime
		boolean notPrime = false; 
		
		//outer for-loop to iterate through the array
		for(int i = 0; i<arr1.length; i++) 
		{
			if(arr1[i] > 2) //if number in array is not equal to 1 or 2
			{
				//inner for-loop to check if number is prime
				for(int j = 2; j <= arr1[i]/2; j++)
				{

					if(arr1[i] % j == 0) //checks if number is divisible by a number
					{
						notPrime = true;
						break;
					}
				}
				if(notPrime==true) //breaks out of loop if the number is not prime
				{
					break;
				}
			}
			else
			{
				//if number is 2
				if(arr1[i]==2)
					notPrime = false;
				//if number is 1
				else
				{
					notPrime = true;
					break;
				}
					
			}

		}	

		System.out.println("Leaving isArrayPrimeIter()");
		if(notPrime)	 //if a number in array is not prime, returns false
			return false;
		else
			return true;	
	}

	/*
	 *	Calls a helper method to loop through array and to check if the array
	 *	has a prime number. Will return a boolean value if numbers in array
	 *	are prime or not
	 *	Pre: arr1  Array of user-entered numbers
	 *	Post: allPrime has a new boolean value
	 *	Return: whether or not the array consists of all prime numbers
	 */
	public static boolean isArrayPrimeRecur(int[] arr1, int size)
	{
		System.out.println("Entering isArrayPrimeRecur()");

		boolean allPrime = true;
		allPrime = (loopThroughItems(arr1, 0 , arr1.length, allPrime));

		System.out.println("Leaving isArrayPrimeRecur()");
		return allPrime;

	}
	
	/*
	 *	Uses recursion to loop through the numbers in the array. Method also
	 *	calls a helper method which uses recursion to check if numbers in array 
	 *	are prime
	 *	Pre: arr1  Array of user-entered numbers
	 *		 low   index of the current element
	 *		 high  length of arr1[]
	 *		 allPrime boolean variable that is true if numbers in array are all prime
	 *	Post: low has a new integer value
	 *		  allPrime has a new boolean value
	 *	Return: whether or not the array consists of all prime numbers
	 */

	public static boolean loopThroughItems(int[] arr1, int low, int high, boolean allPrime)
	{

		System.out.println("Entering loopThroughItems()");
		
		
		if(low < high) //will loop through items until it reaches the end of the array
		{
			if( isPrime(arr1[low], 2) && allPrime) //calls itself if the number is prime
			{
				allPrime = loopThroughItems(arr1, low+1, high, allPrime);
			}
			else //if number in array is not prime
			{
				allPrime = false;
				return allPrime; //exits out of recursion if number is not prime
			}
		}
		
		System.out.println("Leaving loopThroughItems()");
		return allPrime;


	}
	
	/*
	 *	Uses recursion to check if number in array is prime or not.
	 *	Pre: number the number in the array
	 *		 divisor the number to check if value in array is divisible by or not
	 *	Post: divisor has a new value
	 *	Return: whether or not the number in array is a prime number 
	 */

	public static boolean isPrime(int number, int divisor)
	{	
		
		System.out.println("Entering isPrime()");
		
		
		if (number <= 2) //if number is 1 or 2
		{
			if(number == 2) //2 is a prime number
				return true;
			else //if number is 1, then it is not prime
				return false;
		}
		//checks if number in array is divisible by the divisor
		if (number % divisor == 0) 
			return false; 
		//checks if divisor squared is greater than number
		if (divisor * divisor > number) 
			return true;

		
		System.out.println("Leaving isPrime()");
		
		//calls itself but increments the divisor to check if number is divisible by the next number
		return isPrime(number, divisor + 1);

	}
}
