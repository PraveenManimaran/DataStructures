/*
 * Lab #5
 * Name: Praveen Manimaran
 * This class contains the BinarySearchTree and BSTNode class whose data will be Dollar objects 
 * - the data will be inserted based on the actual money value of your Dollar objects as a 
 * combination of the whole value and fractional value attributes. 
 * 
 */

public class BinarySearchTree 
{

	BSTNode<Dollar> root; //root node 

	//default constructor
	public BinarySearchTree()
	{
		root = null;
	}

	/*
	 *	Inserts Dollar object into BinarySearchTree 
	 *	Pre: key  The dollar object to be added
	 *	Post: currNode has a new value
	 *	Return: none
	 */
	public void insert(Dollar key)
	{
		BSTNode<Dollar> newNode = new BSTNode<Dollar>(key);
		if(root ==null)
		{
			root = newNode;
		}
		else
		{
			BSTNode<Dollar> currNode = root;
			BSTNode<Dollar> parent;

			while(true)
			{
				parent = currNode;
				//if Dollar amount in key is less than the currentNode's Dollar amount 

				if(key.compare(currNode.getKey(), key ))//returns true if currNode amount is bigger
				{
					currNode = currNode.getLeftChild();
					if(currNode == null)
					{
						parent.setLeftChild(newNode);
						return;
					}
				}
				else
				{
					currNode = currNode.getRightChild();

					if(currNode == null)
					{
						parent.setRightChild(newNode);
						return;
					}
				}
			}

		}
	}

	//Search Method


	/*
	 *	Searches for a Dollar object in the tree recursively and returns the object
	 *	Pre: root  The root of the tree
	 *		 key The dollar object to be searched
	 *	Post: none
	 *	Return: The BSTNode<Dollar> object that is found
	 */
	public BSTNode<Dollar> searchRecur( BSTNode<Dollar> root, Dollar key)
	{
		//Base case
		//If key is at root or root is empty
		if(root  == null || root.getKey().isEqual(root.getKey(), key))
			return root;
		//If current key's dollar amount is greater than root's dollar amount 
		if(key.compare(key, root.getKey()))
			return searchRecur(root.getRightChild(), key);

		//key's dollar amount is smaller than root's key's dollar amount
		return searchRecur (root.getLeftChild(), key);

	}

	//Delete

	/*
	 *	Calls the deleteRecur method
	 *	Pre:  key The dollar object to be searched
	 *	Post: root has a new value
	 *	Return: none
	 */
	public void delete(Dollar key)
	{
		root = deleteRecur(root, key);
	}

	/*
	 *	Deletes the BSTNode<Dollar> object from the tree
	 *	Pre: root  The root of the tree
	 *		 key The dollar object to be searched
	 *	Post: currNode has a new value 
	 *	Return: The BSTNode<Dollar> root object
	 */
	public BSTNode<Dollar> deleteRecur( BSTNode<Dollar> currNode, Dollar key)
	{
		//If tree is empty(base case)
		if(  currNode == null)
		{
			return  null;
		}
		
		if(key.isEqual(key, currNode.getKey()))
		{
			System.out.println(currNode.getKey().getWhole());
			if(currNode.getLeftChild() == null && currNode.getRightChild() == null)
			{
				return null;
			}
			if(currNode.getLeftChild() == null)
			{
				return currNode.getRightChild();
			}
			if(currNode.getRightChild() == null)
			{
				return currNode.getLeftChild();
			}
			//return currNode;
			
			//get the smallest in the right subtree
			
			currNode.setKey(minimumValue(currNode.getRightChild()));

			//delete the inorder successor
			currNode.setRightChild(deleteRecur(currNode.getRightChild(), currNode.getKey()));
			return currNode;			
		}
		else if(key.compare( currNode.getKey(), key))
		{
			 currNode.setLeftChild(deleteRecur( currNode.getLeftChild(), key));
			 return currNode;
		}
		else 
		{
			 currNode.setRightChild(deleteRecur( currNode.getLeftChild(), key));
			 return currNode;
		}
		
	}
	
	/*
	 *	Gets the smallest in the right subtree
	 *	Pre: root  The root of the tree
	 *	Post: minValue has a new value 
	 *	Return: The smallest Dollar object
	 */
	Dollar minimumValue(BSTNode<Dollar> root)
	{
		Dollar minValue = root.getKey();
		while( root.getLeftChild() != null)
		{
			minValue = root.getLeftChild().getKey();
			root = root.getLeftChild();
		}
		return minValue;
	}


	/*
	 *	Counts the amount of nodes in tree and returns amount
	 *	Pre: root  The root of the tree
	 *	Post: c has a new value 
	 *	Return: The amount of nodes in tree
	 */
	public int getCount(BSTNode<Dollar> root)
	{
		if(root ==null)
			return 0;
		
		int c = 0;
		if(root.getLeftChild() != null && root.getRightChild() !=null)
			c++;
		
		c+= getCount(root.getLeftChild()) + getCount(root.getRightChild());
		return c;
	}


	/*
	 *	Checks if tree is empty 
	 *	Pre: none
	 *	Post: none
	 *	Return: if tree is empty or not
	 */
	public boolean isEmpty()
	{
		if(root == null)
			return true;
		else
			return false;
	}
	/*
	 *	Empties the tree
	 *	Pre: none
	 *	Post: root has new value
	 *	Return: none
	 */
	public void emptyTree()
	{
		root = null;
	}

	/*
	 *	Performs in order traversal of binary search tree and prints out 
	 *	each node in order. This is done recursively
	 *	Pre: currNode  The current node
	 *	Post: none
	 *	Return: none
	 */
	public void inOrderTraversal(BSTNode<Dollar> currNode)
	{
		if(currNode != null)
		{
			inOrderTraversal(currNode.getLeftChild());
			currNode.getKey().print(currNode.getKey());
			inOrderTraversal(currNode.getRightChild());
		}
	}

	/*
	 *	Performs pre order traversal of binary search tree and prints out 
	 *	each node based on pre order. This is done recursively
	 *	Pre: currNode  The current node
	 *	Post: none
	 *	Return: none
	 */
	public void preOrderTraversal(BSTNode<Dollar> currNode)
	{
		if(currNode != null)
		{
			currNode.getKey().print(currNode.getKey());
			preOrderTraversal(currNode.getLeftChild());
			preOrderTraversal(currNode.getRightChild());
		}
	}

	/*
	 *	Performs post order traversal of binary search tree and prints out 
	 *	each node based on post order. This is done recursively
	 *	Pre: currNode  The current node
	 *	Post: none
	 *	Return: none
	 */
	public void postOrderTraversal(BSTNode<Dollar> currNode)
	{
		if(currNode != null)
		{

			postOrderTraversal(currNode.getLeftChild());
			postOrderTraversal(currNode.getRightChild());
			currNode.getKey().print(currNode.getKey());
		}
	}


	/*
	 *	Performs breadthfirst traversal of binary search tree and prints out 
	 *	each node based on levels. This is done through helper methods which
	 *	get the height of the tree
	 *	Pre: none
	 *	Post: index has a new value
	 *	Return: none
	 */
	public void breadthFirstTraversal()
	{
		int height = getHeight(root);
		for(int index = 1; index<=height; index++)
		{
			printLevel(root, index);
		}
	}
	
	/*
	 *	Finds the height of the tree(from root to farthest leaf)
	 *	Pre: currNode  The current node
	 *	Post: leftTreeHeight has a new value
	 *		  rightTreeHeight has a new value
	 *	Return: height of tree
	 */
	public int getHeight(BSTNode<Dollar> currNode)
	{
		if(currNode == null)
			return 0;
		else
		{
			//find height of each subTree
			int leftTreeHeight = getHeight(currNode.getLeftChild());
			int rightTreeHeight = getHeight(currNode.getRightChild());

			//Choose larger tree height
			if(rightTreeHeight < leftTreeHeight)
			{
				return (leftTreeHeight + 1);
			}
			else
			{
				return (rightTreeHeight + 1);
			}

		}
	}

	/*
	 *	Prints the nodes at the current level recursively
	 *	Pre: currNode  The current node
	 *		 level  the current level
	 *	Post: none
	 *	Return: none
	 */
	public void printLevel(BSTNode<Dollar> currNode, int level )
	{
		if(currNode == null)
		{
			return;
		}
		if(level == 1) 
		{
			currNode.getKey().print(currNode.getKey());
		}
		else if(level > 1)
		{
			printLevel(currNode.getLeftChild(), level-1);
			printLevel(currNode.getRightChild(), level-1);
		}
	}

	/*
	 *	Prints tree based on breadthFirstTraversal
	 *	Pre: none
	 *	Post: none
	 *	Return: none
	 */
	public void printTree()
	{
		breadthFirstTraversal();
	}

}

//search, insert, delete, print, count, isEmpty, empty operations and any other needed.

class BSTNode<Dollar> 
{

	private Dollar key;
	private BSTNode<Dollar> leftChild;
	private BSTNode<Dollar> rightChild;

	BSTNode(Dollar key)
	{
		this.key  = key;

	}

	//getters 
	public Dollar getKey()
	{
		return key;
	}
	public BSTNode<Dollar> getLeftChild()
	{
		return leftChild;
	}
	public BSTNode<Dollar> getRightChild()
	{
		return rightChild;
	}

	//setters
	public void setKey(Dollar newKey)
	{
		key = newKey;
	}
	public void setLeftChild(BSTNode<Dollar> left)
	{
		leftChild = left;
	}
	public void setRightChild(BSTNode<Dollar> right)
	{
		rightChild = right;
	}



}




