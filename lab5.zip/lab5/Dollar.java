/*
 * Lab #5
 * Name: Praveen Manimaran
 * This class contains the Dollar object 
 * 
 */

public class Dollar 
{
	//private class attributes
	private int whole;
	private int fraction;
	private String currencyName;

	//Default Constructor
	public Dollar()
	{
		whole = 0;
		fraction = 0;
		currencyName = "Dollar";

	}
	//Constructor based on parameters for all attributes
	public Dollar(int wholeNum, int fractionNum, String nameOfCurrency)
	{
		whole = wholeNum;
		fraction = fractionNum;
		currencyName = nameOfCurrency;
	}
	//Copy Constructor
	public Dollar(Dollar copy)
	{
		whole = copy.whole;
		fraction = copy.fraction;
		currencyName = copy.currencyName;
	}
	
	
	/*
	 *	Setter methods to set the whole amount, fraction amount, and currencyName
	 *	Pre:wholeNum - The dollar amount (whole number)
	 *		fractionNum - the fraction(cents) amount
	 *		name - The name of the currency
	 *	Post: whole has a new value
	 *		  fraction has a new value
	 *		  currencyName has a new value
	 *	Return: none
	 */
	public void setWhole(int wholeNum)
	{
		whole = wholeNum;
	}
	public void setFraction(int fractionNum)
	{
		fraction = fractionNum;
	}
	public void setCurrencyName(String name)
	{
		currencyName = name;
	}
	
	
	/*
	 *	Getter methods to get the whole amount, fraction amount, and currency name
	 *	Pre:whole - The dollar amount (whole number)
	 *		fraction - the fraction(cents) amount
	 *		currencyName - The name of the currency
	 *	Post: none
	 *	Return: The dollar amount (whole number)
	 *			The minimum double accepted
	 *			The name of the currency
	 */
	public int getWhole()
	{
		return whole;
	}
	public int getFraction()
	{
		return fraction;
	}
	public String getCurrencyName()
	{
		return currencyName;
	}

	
	/*
	 *	Add both parameters of dollar amounts together in cents
	 *	Pre: obj1  The first dollar object to be added
	 *		 obj2  The second dollar object to be added
	 *	Post: totalCents has a new value
	 *	Return: return The total amount of cents in the two dollar objects
	 */
	public double addDollars(Dollar obj1, Dollar obj2)
	{
		//converts both dollar object's dollar and fraction values to cents
		double totalCents = obj1.getWhole()*100 + obj2.getWhole()*100 + obj1.getFraction() + obj2.getFraction();	
		return totalCents;

	}

	/*
	 *	Subtracts the total amount of the second object from the first object
	 *	Pre: obj1  The dollar object to be subtracted from
	 *		 obj2  The dollar object to be subtracted
	 *	Post: totalCents has a new value
	 *	Return: The total amount of cents remaining in the first dollar object
	 */
	public double subDollars(Dollar obj1, Dollar obj2)
	{
		//converts both dollar object's dollar and fraction values to cents
		double obj1Cents = obj1.getWhole()*100 + obj1.getFraction();	
		double obj2Cents = obj2.getWhole()*100 + obj2.getFraction();
		double totalCents;
		
		totalCents = obj1Cents - obj2Cents;

		return totalCents;
	}

	/*
	 *	Comparing two objects of the same currency for equality/inequality
	 *	Pre: obj1  The first dollar object to be compared for equality
	 *		 obj2  The second dollar object to be compared for equality
	 *	Post: totalCents1 and totalCents2 have new values
	 *	Return: true if the first and second dollar objects are equal
	 */
	public boolean isEqual(Dollar obj1, Dollar obj2)
	{
		//converts both dollar object's dollar and fraction values to cents
		int totalCents1 = obj1.getWhole()*100 + obj1.getFraction();
		int totalCents2 = obj2.getWhole()*100 + obj2.getFraction();
		
		if(totalCents1 == totalCents2) //checks equality
			return true;
		else
			return false;
	}
	
	/*
	 *	Comparing two objects of the same currency to identify which object is larger or smaller
	 *	Pre: obj1  The first dollar object to be compared 
	 *		 obj2  The second dollar object to be compared 
	 *	Post: totalCents1 and totalCents2 have new values
	 *	Return: true if obj1 is bigger, false if obj2 is bigger
	 */
	public boolean compare(Dollar obj1, Dollar obj2)
	{
		//converts both dollar object's dollar and fraction values to cents
		int totalCents1 = obj1.getWhole()*100 + obj1.getFraction();
		int totalCents2 = obj2.getWhole()*100 + obj2.getFraction();

		if(totalCents1 > totalCents2)
			return true; //returns true, if first obj1 is bigger
		else
			return false;
	}


	/*
	 *	Print method to print details of a currency object
	 *	Pre: obj1  The dollar object to be printed
	 *	Post: none
	 *	Return: none
	 */
	public void print(Dollar obj1)
	{
		System.out.println("Number of Dollars: "+ obj1.getWhole());
		System.out.println("Number of Cents: " + obj1.getFraction());
	}
























}

