/*
 * Lab #5
 * Name: Praveen Manimaran
 * This class contains the Main class which is the driver program that 
 * will demonstrate all the capabilities of the BinarySearchTrees and 
 * requires input from the user to participate. 
 * 
 */
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;



public class Main 
{

	public static void main(String[] args) 
	{
		
		BinarySearchTree bst = new BinarySearchTree();
		int numTimes = 10;
		Scanner scanner = new Scanner(System.in);
		
		
		
		/*
		 * Prints text to a new file 
		 * Prompts user to enter dollar and cent amount 10 times 
		 * if(data is entered correctly)
		 * 		insert object into tree
		 *do: Asks user if they want to add, delete, search nodes or print
		 * if(add)
		 * 	prompts user to enter amount
		 * 	performs insert function
		 * 	includes data validation
		 * else if(delete)
		 * 	prompts user to enter amount
		 * 	performs delete function if data is found in tree
		 * 	includes data validation
		 * else if(search)
		 * 	prompts user to enter amount
		 * 	performs search function to see if object is found in tree
		 * 	includes data validation
		 * else:print
		 * 	prints all four traversals and exits do while loop
		 * 	while: print/exit is not chosen	
		 */
		
		try
		{
			// Save original out stream.
			PrintStream originalOut = System.out;
			PrintStream fileOut = new PrintStream("/Users/praveenmanimaran/Desktop/BinarySearchTree.txt");
			System.setOut(fileOut);
			
			for(int i =0; i<numTimes; i++)
			{
				System.out.println("Enter number of dollars to enter: ");
				originalOut.println("Enter number of dollars to enter: ");
				int numDollars;
				numDollars = scanner.nextInt();
				System.out.println(numDollars);

				System.out.println("Enter number of cents to enter in: ");
				originalOut.println("Enter number of cents to enter in: ");
				int numCents;
				numCents = scanner.nextInt();
				System.out.println(numCents);

				//Data validation
				if(numDollars>=0 && (numCents>=0 && numCents <=99 ) )
				{
					Dollar d1 = new Dollar(numDollars, numCents, "Dollar");
					bst.insert(d1);
				}
				else
				{
					System.out.println("Data value is ignored and will not be inserted into tree");
					originalOut.println("Data value is ignored and will not be inserted into tree");
				}
			}
			System.setOut(originalOut); 
			System.setOut(fileOut);
			
			String input;
			boolean goodInput = false;
			do
			{
				goodInput = false;
				System.out.println("Would you like to add, delete, search,or print tree which exits program? Enter Add, Delete,Search, Print: ");
				originalOut.println("Would you like to add, delete, search,or print tree which exits program? Enter Add, Delete,Search, Print: ");
				input = scanner.next();
				System.out.println(input);
				if(input.equals("add") || input.equals("Add"))
				{
					goodInput = true;
					System.out.println("Enter number of dollars to enter: ");
					originalOut.println("Enter number of dollars to enter: ");
					int numDollars;
					numDollars = scanner.nextInt();
					System.out.println(numDollars);

					System.out.println("Enter number of cents to enter in: ");
					originalOut.println("Enter number of cents to enter in: ");
					int numCents;
					numCents = scanner.nextInt();
					System.out.println(numCents);

					//Data validation
					if(numDollars>=0 && (numCents>=0 && numCents <=99 ) )
					{
						Dollar d1 = new Dollar(numDollars, numCents, "Dollar");
						bst.insert(d1);
					}
					else
					{
						System.out.println("Sorry data value cannot be accepted");
						originalOut.println("Sorry data value cannot be accepted");
					}
					
				}
				else if(input.equals("delete")||input.equals("Delete") )
				{
					goodInput = true;
					System.out.println("Enter number of dollars to delete: ");
					originalOut.println("Enter number of dollars to delete: ");
					int numDollars;
					numDollars = scanner.nextInt();
					System.out.println(numDollars);

					System.out.println("Enter number of cents to delete: ");
					originalOut.println("Enter number of cents to delete: ");
					int numCents;
					numCents = scanner.nextInt();
					System.out.println(numCents);

					//Data validation
					if(numDollars>=0 && (numCents>=0 && numCents <=99 ) )
					{
						Dollar d1 = new Dollar(numDollars, numCents, "Dollar");
						if(bst.searchRecur(bst.root, d1) != null)
						{
							bst.delete(d1);
						}
						else
						{
							System.out.println("Cannot find dollar object in tree: ");
							originalOut.println("Cannot find dollar object in tree: ");
						}
						
					}
					else
					{
						System.out.println("Sorry data value cannot be accepted");
						originalOut.println("Sorry data value cannot be accepted");
					}
				}
				else if(input.equals("search")||input.equals("Search") )
				{
					goodInput = true;
					System.out.println("Enter number of dollars to find: ");
					originalOut.println("Enter number of dollars to find: ");
					int numDollars;
					numDollars = scanner.nextInt();
					System.out.println(numDollars);

					System.out.println("Enter number of cents to find: ");
					originalOut.println("Enter number of cents to find: ");
					int numCents;
					numCents = scanner.nextInt();
					System.out.println(numCents);

					//Data validation
					if(numDollars>=0 && (numCents>=0 && numCents <=99 ) )
					{
						Dollar d1 = new Dollar(numDollars, numCents, "Dollar");
						if(bst.searchRecur(bst.root, d1) != null)
						{
							System.out.println("Found dollar object in tree: ");
							originalOut.println("Found dollar object in tree: ");
						}
						else
						{
							System.out.println("Cannot find dollar object in tree: ");
							originalOut.println("Cannot find dollar object in tree: ");
						}
						
					}
					else
					{
						System.out.println("Sorry data value cannot be accepted");
						originalOut.println("Sorry data value cannot be accepted");
					}
					
				}
				else if(input.equals("print")||input.equals("Print"))
				{
					goodInput = false;
					System.out.println("\nContents in Tree: " );
					originalOut.println("\nContents in Tree: ") ;
					
					System.out.println("Breadth-Level Traversal: " );
					originalOut.println("Breadth-Level Traversal: ") ;
					bst.breadthFirstTraversal();
					System.setOut(originalOut);
					bst.breadthFirstTraversal();
					System.setOut(fileOut);
					
					System.out.println("In Order Traversal: " );
					originalOut.println("In Order Traversal: ") ;
					bst.inOrderTraversal(bst.root);
					System.setOut(originalOut);
					bst.inOrderTraversal(bst.root);
					System.setOut(fileOut);
					
					System.out.println("Pre Order Traversal: " );
					originalOut.println("Pre Order Traversal: ") ;
					bst.preOrderTraversal(bst.root);
					System.setOut(originalOut);
					bst.preOrderTraversal(bst.root);
					System.setOut(fileOut);
					
					System.out.println("Post Order Traversal: " );
					originalOut.println("Post Order Traversal: ") ;
					bst.postOrderTraversal(bst.root);
					System.setOut(originalOut);
					bst.postOrderTraversal(bst.root);
					System.setOut(fileOut);	
				}
				else
				{
					goodInput = true;
				}
			} while(goodInput);
			
		}
		catch(FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
		
		/*
		Dollar d1 = new Dollar(50, 40, "Dollar");
		Dollar d2 = new Dollar(25, 60, "Dollar");
		Dollar d3 = new Dollar(15, 30, "Dollar");
		Dollar d4 = new Dollar(6, 70, "Dollar");
		Dollar d5 = new Dollar(45, 90, "Dollar");
		Dollar d6 = new Dollar(36, 20, "Dollar");
		Dollar d7 = new Dollar(75, 80, "Dollar");
		Dollar d8 = new Dollar(60, 50, "Dollar");
		Dollar d9 = new Dollar(83, 90, "Dollar");
		Dollar d10 = new Dollar(70, 20, "Dollar");
		
		
		BinarySearchTree bst = new BinarySearchTree();
		bst.insert(d1);
		bst.insert(d2);
		bst.insert(d3);
		bst.insert(d4);
		bst.insert(d5);
		bst.insert(d6);
		bst.insert(d7);
		bst.insert(d8);
		bst.insert(d9);
		bst.insert(d10);
		
		bst.levelOrderTraversal();
		*/
		
	}

}
