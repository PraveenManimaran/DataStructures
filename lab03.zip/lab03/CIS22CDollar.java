/*
 * Lab #1
 * Name: Praveen Manimaran
 * This class is a child class of Dollar and contains the CIS22CDollar object which 
 * has getter and setter methods, followed by add/subtract/compare/print methods. It 
 * also has conversion methods from USD to C2D and vice versa.
 * 
 */

public class CIS22CDollar extends Dollar
{
	private double convFactor = 1.36;
	private int whole;
	private int fraction;
	private String currencyName;

	//Default Constructor
	public CIS22CDollar()
	{
		whole = 0;
		fraction = 0;
		currencyName = "CIS22CDollar";

	}
	//Constructor based on parameters for all attributes
	public CIS22CDollar(int wholeNum, int fractionNum, String nameOfCurrency)
	{
		whole = wholeNum;
		fraction = fractionNum;
		currencyName = "CIS22CDollar";
	}

	//Copy Constructor
	public CIS22CDollar(CIS22CDollar copy)
	{
		whole = copy.whole;
		fraction = copy.fraction;
		currencyName = copy.currencyName;
	}


	/*
	 *	Setter methods to set the whole amount, fraction amount, and currencyName
	 *	Pre:wholeNum - The CIS22Cdollar amount (whole number)
	 *		fractionNum - The minimum double accepted
	 *		name - The name of the currency
	 *	Post: whole has a new value
	 *		  fraction has a new value
	 *		  currencyName has a new value
	 *	Return: none
	 */
	public void setWhole(int wholeNum)
	{
		whole = wholeNum;
	}
	public void setFraction(int fractionNum)
	{
		fraction = fractionNum;
	}
	public void setCurrencyName(String name)
	{
		currencyName = name;
	}

	/*
	 *	Getter methods to get the whole amount, fraction amount, and currency name
	 *	Pre:whole - The CIS dollar amount (whole number)
	 *		fraction - the fraction(cents) amount
	 *		currencyName - The name of the currency
	 *	Post: none
	 *	Return: The dollar amount (whole number)
	 *			The minimum double accepted
	 *			The name of the currency
	 */
	public int getWhole()
	{
		return whole;
	}
	public int getFraction()
	{
		return fraction;
	}
	public String getCurrencyName()
	{
		return currencyName;
	}


	/*
	 *	Adding 2 CIS22CDollar Objects together in cents
	 *	Pre: obj1  The first CIS22CDollar object to be added
	 *		 obj2  The second CIS22CDollar object to be added
	 *	Post: totalCents has a new value
	 *	Return: return The total amount of cents in the two CIS22CDollar objects
	 */
	public double addCIS22CDollars(CIS22CDollar obj1, CIS22CDollar obj2)
	{
		//converts both objects dollar and fraction values to cents
		double totalCents = obj1.getWhole()*100 + obj2.getWhole()*100 + obj1.getFraction() + obj2.getFraction();	
		return totalCents;

	}

	/*
	 *	Subtracts the total amount of the second CIS22CDollar object from the first CIS22CDollar object
	 *	Pre: obj1  The CIS22CDollardollar object to be subtracted from
	 *		 obj2  The CIS22CDollar dollar object to be subtracted
	 *	Post: totalCents has a new value
	 *	Return: The total amount of cents remaining in the first dollar object
	 */
	public double subCIS22CDollars(CIS22CDollar obj1, CIS22CDollar obj2)
	{
		//converts both objects dollar and fraction values to cents
		double obj1Cents = obj1.getWhole()*100 + obj1.getFraction();	
		double obj2Cents = obj2.getWhole()*100 + obj2.getFraction();
		double totalCents;
		totalCents = obj1Cents - obj2Cents;

		return totalCents;
	}

	/*
	 *	Comparing two CIS22CDollar objects of the same currency for equality/inequality
	 *	Pre: obj1  The first CIS22CDollar object to be compared for equality
	 *		 obj2  The second CIS22CDollar object to be compared for equality
	 *	Post: totalCents1 and totalCents2 have new values
	 *	Return: true if the first and second CIS22CDollar objects are equal
	 */
	public boolean isEqual(CIS22CDollar obj1, CIS22CDollar obj2)
	{
		//converts both objects dollar and fraction values to cents
		int totalCents1 = obj1.getWhole()*100 + obj1.getFraction();
		int totalCents2 = obj2.getWhole()*100 + obj2.getFraction();
		if(totalCents1 == totalCents2) //checks equality
			return true;
		else
			return false;
	}

	/*
	 *	Comparing two CIS22CDollar objects to identify which object is larger or smaller
	 *	Pre: obj1  The first CIS22CDollar object to be compared 
	 *		 obj2  The second CIS22CDollar object to be compared 
	 *	Post: totalCents1 and totalCents2 have new values
	 *	Return: true if obj1 is bigger, false if obj2 is bigger
	 */
	public boolean compare(CIS22CDollar obj1, CIS22CDollar obj2)
	{
		//converts both objects dollar and fraction values to cents
		int totalCents1 = obj1.getWhole()*100 + obj1.getFraction();
		int totalCents2 = obj2.getWhole()*100 + obj2.getFraction();

		if(totalCents1 > totalCents2)
			return true; //returns true, if first obj1 is bigger
		else
			return false;
	}

	/*
	 *	Print method to print details of CIS22CDollar object
	 *	Pre: obj1  The dollar object to be printed
	 *	Post: none
	 *	Return: none
	 */
	public void print(CIS22CDollar obj1)
	{

		System.out.println("Number of CIS22CDollars: "+ obj1.getWhole());
		System.out.println("Number of CIS22CCents: " + obj1.getFraction());
		
	}

	/*
	 *	Method to convert USD objects to C2D
	 *	Pre: obj1  The dollar object to be converted to CIS22CDollar object
	 *	Post: totalCents has a new amount
	 *	Return: the new CIS22CDollar object that is equivalent to the dollar object amount
	 */
	public CIS22CDollar convToCIS22C(Dollar obj1)
	{
		CIS22CDollar c2d = new CIS22CDollar(); //creates new CIS22CDollar object to convert to
		
		//converts dollar object's dollar and fraction values to cents
		double totalCents = (convFactor)*(obj1.getWhole()*100 + obj1.getFraction());
		
		c2d.setWhole((int)(totalCents)/100);
		c2d.setFraction((int)(totalCents)%100);
		
		return c2d;
	}

	/*
	 *	Method to convert C2D objects to USD
	 *	Pre: obj1  The CIS22CDollar object to be converted to dollar object
	 *	Post: totalCents has a new amount
	 *	Return: the new dollar object that is equivalent to the CIS22CDollar object amount
	 */
	public Dollar convToDollar(CIS22CDollar obj1)
	{
		Dollar dollar = new Dollar(); //creates new Dollar object to convert to
		
		//converts CIS22CDollar object's dollar and fraction values to cents
		double totalCents = (obj1.getWhole()*100 + obj1.getFraction())/(convFactor);
		
		dollar.setWhole((int)(totalCents)/100);
		dollar.setFraction((int)(totalCents)%100);
		
		return dollar;

	}


}
