
/*
 * Lab #2
 * Name: Praveen Manimaran
 * This assignment uses recursion to help sort an array of Dollar/CIS22C objects. The sort
 * method is called merge sort and uses a helper method. This program also writes output to a file
 * called SortingArrays.txt.
 * 
 */

//import statements
import java.util.Scanner;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;


public class SortingArrays
{

	public static final int SORT_MAX_SIZE = 16; //max size of the array

	public static void main(String[] args) 
	{


		/* try block
		   		creates file called SortingArrays.txt
		   		do-while loop to make sure user enters # of elements in array correctly
		   			prompts user to enter how many elements to enter in array
		   			if number of elements > 16, loop will continue
		   		Prompts user to enter Dollar or CIS22CDollar
		   		if(user entered dollar)
		   			create Dollar array for user inputed size
		   			for loop to ask user to enter elements in array 
		   				prompts user to enter whole and fraction amount
		   				creates dollar object with values 
		   				puts dollar object into array
		   			calls recursion sort method
		   			for loop to print out Dollar array
		   				prints out sorted Dollar array to file and console
		   		else if user entered CIS22CDollar
		   			create CIS22CDollar array for user inputed size
		   			for loop to ask user to enter elements in array 
		   				prompts user to enter whole and fraction amount
		   				creates CIS22CDollar object with values 
		   				puts CIS22CDollar object into array
		   			calls recursion sort method
		   			for loop to print out CIS22CDollar array
		   				prints out sorted CIS22CDollar array to file and console
		   	catch block to catch FileNotFoundException
		 */



		int numElements;
		String input;
		boolean badInput = false;
		Scanner scanner = new Scanner(System.in);


		try
		{
			// Save original out stream.
			PrintStream originalOut = System.out;
			PrintStream fileOut = new PrintStream("SortingArrays.txt");
			System.setOut(fileOut);

			//Ask the user how many elements they want in the array; will keep
			//repeating question until size of array is <= 16
			do
			{
				badInput = false;
				System.out.println("How many elements do you want? Do not exceed " + SORT_MAX_SIZE + "!");
				originalOut.println("How many elements do you want? Do not exceed " + SORT_MAX_SIZE + "!");
				numElements = scanner.nextInt();
				System.out.println(numElements);

				if(numElements>16)
					badInput = true;

			} while(badInput);


			System.out.println("Will you enter Dollar or CIS22CDollar Objects? Enter Dollar or CIS22CDollar ");
			originalOut.println("Will you enter Dollar or CIS22CDollar Objects? Enter Dollar or CIS22CDollar ");

			input = scanner.next();
			System.out.println(input);
			if(input.equals("Dollar")||input.equals("dollar"))
			{
				Dollar[] dollar  = new Dollar[numElements];
				for(int i=0; i<numElements; i++)
				{
					System.out.println("Enter number of dollars to enter in #"+i+" element in array: ");
					originalOut.println("Enter number of dollars to enter in #"+i+" element in array: ");
					int numDollars;
					numDollars = scanner.nextInt();
					System.out.println(numDollars);

					System.out.println("Enter number of cents to enter in #"+i+" element in array: ");
					originalOut.println("Enter number of cents to enter in #"+i+" element in array: ");
					int numCents;
					numCents = scanner.nextInt();
					System.out.println(numCents);

					Dollar d1 = new Dollar(numDollars, numCents, "Dollar");
					dollar[i] = d1;
				}

				System.setOut(originalOut); 
				recurMergeSort(dollar, numElements);

				System.setOut(fileOut);
				System.out.println("\nContents in Dollar array after merge sort: ");
				originalOut.println("\nContents in Dollar array after merge sort: ");
				for (int a = 0; a<dollar.length; a++)
				{
					System.out.println("\nContents in element " +a );
					originalOut.println("\nContents in element " +a );
					dollar[a].print(dollar[a]);

					System.setOut(originalOut);
					dollar[a].print(dollar[a]);

					System.setOut(fileOut);
				}
				System.setOut(originalOut);

			}

			else if(input.equals("CIS22CDollar")||input.equals("cis22cdollar"))
			{
				CIS22CDollar[] cis22cdollar  = new CIS22CDollar[numElements];
				for(int i=0; i<numElements; i++)
				{
					System.out.println("Enter number of CIS22CDollars to enter in #"+i+" element in array: ");
					originalOut.println("Enter number of CIS22CDollars to enter in #"+i+" element in array: ");
					int numCIS22CDollars;
					numCIS22CDollars = scanner.nextInt();
					System.out.println(numCIS22CDollars);

					System.out.println("Enter number of CIS22C cents to enter in #"+i+" element in array: ");
					originalOut.println("Enter number of CIS22C cents to enter in #"+i+" element in array: ");
					int numCents;
					numCents = scanner.nextInt();
					System.out.println(numCents);
					CIS22CDollar cd1 = new CIS22CDollar(numCIS22CDollars, numCents, "CIS22CDollar");
					cis22cdollar[i] = cd1;
				}

				System.setOut(originalOut);
				recurMergeSort(cis22cdollar, numElements);

				System.out.println("Contents in  CIS22CDollar array after merge sort: ");
				originalOut.println("Contents in  CIS22CDollar array after merge sort: ");
				for (int a = 0; a<cis22cdollar.length; a++)
				{
					System.out.println("\nContents in element " +a );
					originalOut.println("\nContents in element " +a );
					cis22cdollar[a].print(cis22cdollar[a]);

					System.setOut(originalOut);
					cis22cdollar[a].print(cis22cdollar[a]);

					System.setOut(fileOut);

				}

			}
			System.setOut(originalOut);

		}
		catch(FileNotFoundException ex)
		{
			ex.printStackTrace();
		}

	}

	
	/*
	 *	Recursion method to create two new arrays(copies values) by splitting at a midpoint. Prints out contents of array
	 *	that entered method. Calls itself twice(once with each array) until array is of size 1, 
	 *	and then calls a merge method to join both arrays together. Appends to file called SortingArrays.txt
	 *	Pre: arr  Dollar array 
	 *		 size size of Dollar array
	 *	Post: leftd1 has new Dollar values which are copied from 1st half of previous array
	 *		  rightd2 has new Dollar values which are copied from 2nd half of previous array
	 *	Return: none
	 */
	public static void recurMergeSort(Dollar[] arr, int size)
	{

		/* try block
		   		appends to SortingArrays.txt
		   		for loop to print out contents of array
		   			prints to file and console
		   		if size of array is less than 2(base case)
		   			prints value in the array
		   			returns 
		   		sets size of the midpoint in array
		   		creates Left Dollar Array(first half of arr[])
		   		creates Right Dollar Array(second half of arr[])
		   		for loop
		   			assigns fraction and whole values in first half of arr[] to values in left Dollar Array
		   		for loop
		   			assigns fraction and whole values in 2nd half of arr[] to values in right Dollar Array
		   			
		   		calls recurMergeSort passing in left Dollar Array and its size
		   		calls recurMergeSort passing in right Dollar Array and its size
		   		calls merge Method to merge both arrays together and compare values
   		   catch block to catch FileNotFoundException
		 */

		try
		{
			// Save original out stream.
			PrintStream originalOut = System.out;
			PrintStream fileOut = new PrintStream(new FileOutputStream("SortingArrays.txt", true));
			System.setOut(fileOut);

			System.out.println("\n\nEntering recurMergeSort()");
			originalOut.println("\n\nEntering recurMergeSort()");

			System.out.println("Array Contents: ");
			originalOut.println("Array Contents: ");

			for(int x = 0; x<arr.length; x++)
			{
				System.out.println("\nContents in element " +x );
				originalOut.println("\nContents in element " +x );

				arr[x].print(arr[x]);

				System.setOut(originalOut);
				arr[x].print(arr[x]);
				
			}
			if(size < 2)
			{
				System.setOut(fileOut);
				arr[0].print(arr[0]);
				System.setOut(originalOut);
				arr[0].print(arr[0]);
				return;
			}

			int midPoint = size/2;
			Dollar[] leftD1;
			leftD1 = new Dollar[midPoint];
			Dollar[] rightD2;
			rightD2 = new Dollar[size-midPoint];

			for(int i = 0; i< midPoint; i++)
			{
				Dollar d1 = new Dollar(arr[i].getWhole(), arr[i].getFraction(), "Dollar");
				leftD1[i] = d1;
			}

			for(int j = midPoint; j< size; j++)
			{
				Dollar d2 = new Dollar(arr[j].getWhole(), arr[j].getFraction(), "Dollar");
				rightD2[j-midPoint] = d2;
			}
			recurMergeSort(leftD1, midPoint);
			recurMergeSort(rightD2, size - midPoint);

			merge(arr, leftD1, rightD2, midPoint, size - midPoint);


			System.setOut(originalOut);

		}
		catch(FileNotFoundException ex)
		{
			ex.printStackTrace();
		}

	}

	/*
	 *	This method takes in both sub-arrays at the starting and end points of both arrays. Compares elements
	 *	of both the arrays individually and puts the smaller element into the input array(parameter)
	 *	Pre: arr  Dollar array 
	 *		 leftD1	sub array of first half of arr
	 *		 rightD2 sub array of 2nd half of arr
	 *		 leftPoint midPoint of arr
	 *		 rightPoint end point of arr
	 *	Post: i has a new index value
	 *		  j has a new index value
	 *		  k has a new index value
	 *	Return: none
	 */
	public static void merge(Dollar[] arr, Dollar[] leftD1, Dollar[] rightD2, int leftPoint, int rightPoint)
	{
		
		/* while i is less than the left end point and j is less than the right end point
		 		if left dollar array object at i is less than right dollar array object at i or if they are equal
			 		sets value of new array to the whole and fraction of smaller array(left dollar array)
			 		increments i and k pointers
			 	else
			 		sets value of new array at i to whole and fraction of smaller array(right dollar array)
			 		increments i and k pointers
		   while i is less than the left end point
		   		copy whole and fraction values of left dollar array into input array
		   		increments i and k pointers
		   while j is less than the right end point
		   		copy whole and fraction values of right dollar array into input array
		   		increments j and k pointers
		 */
		

		int i = 0;
		int j = 0;
		int k = 0;

		while( i< leftPoint && j < rightPoint )
		{
			if( leftD1[i].compare(leftD1[i], rightD2[j]  ) == false || leftD1[i].isEqual(leftD1[i], rightD2[j] ) )
			{
				arr[k].setWhole(leftD1[i].getWhole());
				arr[k].setFraction(leftD1[i].getFraction());
				k++;
				i++;
			}
			else
			{
				arr[k].setWhole(rightD2[j].getWhole());
				arr[k].setFraction(rightD2[j].getFraction());
				k++;
				j++;
			}
		}
		while( i < leftPoint)
		{
			arr[k].setWhole(leftD1[i].getWhole());
			arr[k].setFraction(leftD1[i].getFraction());
			k++;
			i++;
		}
		while( j < rightPoint)
		{
			arr[k].setWhole(rightD2[j].getWhole());
			arr[k].setFraction(rightD2[j].getFraction());
			k++;
			j++;
		}

	}
}


